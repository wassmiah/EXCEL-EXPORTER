@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Please run setup.bat first.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat
python -m pip install pyinstaller
pyinstaller --noconfirm --clean --onefile --windowed --name "WF Excel Exporter" wf_excel_exporter.py

echo.
echo If successful, the EXE is in the dist folder.
pause
