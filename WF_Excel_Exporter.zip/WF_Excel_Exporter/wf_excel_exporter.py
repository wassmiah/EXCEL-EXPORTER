from __future__ import annotations

import json
import os
import posixpath
import queue
import re
import threading
import time
import webbrowser
import zipfile
from io import BytesIO
from pathlib import Path
from typing import Any

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from google.auth.transport.requests import AuthorizedSession, Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from lxml import etree


APP_NAME = "WF Excel Exporter"
APP_FOLDER = Path(os.getenv("APPDATA", Path.home())) / "WFExcelExporter"
APP_FOLDER.mkdir(parents=True, exist_ok=True)
TOKEN_PATH = APP_FOLDER / "token.json"
SETTINGS_PATH = APP_FOLDER / "settings.json"

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
]

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
OFFICE_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"

CELL_REF_RE = re.compile(r"^([A-Z]+)(\d+)$")
SPREADSHEET_ID_RE = re.compile(r"/spreadsheets/d/([A-Za-z0-9_-]+)")
WINDOWS_BAD_CHARS = re.compile(r'[<>:"/\\|?*]+')

EXCEL_ERRORS = {
    "#NULL!",
    "#DIV/0!",
    "#VALUE!",
    "#REF!",
    "#NAME?",
    "#NUM!",
    "#N/A",
    "#GETTING_DATA",
    "#ERROR!",
}


class ExportError(RuntimeError):
    pass


def extract_spreadsheet_id(value: str) -> str:
    value = value.strip()
    match = SPREADSHEET_ID_RE.search(value)
    if match:
        return match.group(1)
    if re.fullmatch(r"[A-Za-z0-9_-]{20,}", value):
        return value
    raise ExportError("Enter a valid Google Sheets URL or spreadsheet ID.")


def safe_filename(name: str) -> str:
    name = WINDOWS_BAD_CHARS.sub("-", name).strip().rstrip(".")
    return name or "Sheet"


def quote_sheet_title(title: str) -> str:
    return "'" + title.replace("'", "''") + "'"


def load_settings() -> dict[str, str]:
    if not SETTINGS_PATH.exists():
        return {}
    try:
        return json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_settings(data: dict[str, str]) -> None:
    SETTINGS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get_credentials(client_secret_path: str) -> Credentials:
    client_secret = Path(client_secret_path)
    if not client_secret.exists():
        raise ExportError("OAuth credentials JSON file was not found.")

    creds: Credentials | None = None

    if TOKEN_PATH.exists():
        try:
            creds = Credentials.from_authorized_user_file(str(TOKEN_PATH), SCOPES)
        except Exception:
            creds = None

    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
        except Exception:
            creds = None

    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file(str(client_secret), SCOPES)
        creds = flow.run_local_server(port=0, open_browser=True)
        TOKEN_PATH.write_text(creds.to_json(), encoding="utf-8")

    return creds


def get_spreadsheet_metadata(service, spreadsheet_id: str) -> tuple[str, list[dict[str, Any]]]:
    try:
        result = (
            service.spreadsheets()
            .get(
                spreadsheetId=spreadsheet_id,
                fields="properties(title),sheets(properties(sheetId,title,index,hidden,sheetType))",
            )
            .execute(num_retries=3)
        )
    except HttpError as exc:
        raise ExportError(format_google_error(exc)) from exc

    title = result.get("properties", {}).get("title", spreadsheet_id)
    sheets = []

    for item in result.get("sheets", []):
        props = item.get("properties", {})
        if props.get("hidden", False):
            continue
        if props.get("sheetType", "GRID") != "GRID":
            continue
        sheets.append(
            {
                "sheetId": int(props["sheetId"]),
                "title": props["title"],
                "index": int(props.get("index", 0)),
            }
        )

    sheets.sort(key=lambda x: x["index"])
    return title, sheets


def get_effective_values(service, spreadsheet_id: str, sheet_title: str) -> list[list[Any]]:
    try:
        result = (
            service.spreadsheets()
            .values()
            .get(
                spreadsheetId=spreadsheet_id,
                range=quote_sheet_title(sheet_title),
                majorDimension="ROWS",
                valueRenderOption="UNFORMATTED_VALUE",
                dateTimeRenderOption="SERIAL_NUMBER",
            )
            .execute(num_retries=3)
        )
    except HttpError as exc:
        raise ExportError(f"Could not read values for {sheet_title}: {format_google_error(exc)}") from exc

    return result.get("values", [])


def download_sheet_xlsx(
    session: AuthorizedSession,
    spreadsheet_id: str,
    sheet_id: int,
    sheet_title: str,
) -> bytes:
    # This intentionally mirrors the direct export URL that already works in Chrome.
    url = (
        f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}/export"
        f"?format=xlsx&gid={sheet_id}"
    )

    try:
        response = session.get(url, timeout=180, allow_redirects=True)
    except Exception as exc:
        raise ExportError(f"Download request failed for {sheet_title}: {exc}") from exc

    if response.status_code != 200:
        snippet = response.text[:400].replace("\n", " ") if response.text else ""
        raise ExportError(
            f"Google export failed for {sheet_title}: HTTP {response.status_code}. {snippet}"
        )

    data = response.content
    if len(data) < 4 or data[:2] != b"PK":
        content_type = response.headers.get("Content-Type", "unknown")
        snippet = ""
        try:
            snippet = data[:500].decode("utf-8", errors="replace").replace("\n", " ")
        except Exception:
            pass
        raise ExportError(
            f"Google did not return an XLSX file for {sheet_title}. "
            f"Content-Type: {content_type}. {snippet}"
        )

    return data


def format_google_error(exc: HttpError) -> str:
    try:
        payload = json.loads(exc.content.decode("utf-8"))
        message = payload.get("error", {}).get("message")
        if message:
            return message
    except Exception:
        pass
    return str(exc)


def column_number(letters: str) -> int:
    value = 0
    for ch in letters:
        value = value * 26 + (ord(ch) - 64)
    return value


def matrix_value(matrix: list[list[Any]], row_1based: int, col_1based: int) -> Any:
    r = row_1based - 1
    c = col_1based - 1
    if r < 0 or c < 0 or r >= len(matrix):
        return None
    row = matrix[r]
    if c >= len(row):
        return None
    return row[c]


def worksheet_xml_path(zf: zipfile.ZipFile, wanted_title: str) -> str:
    workbook_path = "xl/workbook.xml"
    rels_path = "xl/_rels/workbook.xml.rels"

    if workbook_path in zf.namelist() and rels_path in zf.namelist():
        workbook_root = etree.fromstring(zf.read(workbook_path))
        sheet_nodes = workbook_root.xpath(
            ".//*[local-name()='sheets']/*[local-name()='sheet']"
        )

        relationship_id = None
        for node in sheet_nodes:
            if node.get("name") == wanted_title:
                relationship_id = node.get(f"{{{OFFICE_REL_NS}}}id")
                break

        # Direct gid exports usually contain only one worksheet. If the title was
        # changed by Google during conversion, fall back to the only sheet entry.
        if relationship_id is None and len(sheet_nodes) == 1:
            relationship_id = sheet_nodes[0].get(f"{{{OFFICE_REL_NS}}}id")

        if relationship_id:
            rels_root = etree.fromstring(zf.read(rels_path))
            rel_nodes = rels_root.xpath(".//*[local-name()='Relationship']")
            for rel in rel_nodes:
                if rel.get("Id") == relationship_id:
                    target = rel.get("Target", "")
                    if target.startswith("/"):
                        candidate = target.lstrip("/")
                    else:
                        candidate = posixpath.normpath(posixpath.join("xl", target))
                    if candidate in zf.namelist():
                        return candidate

    candidates = sorted(
        name
        for name in zf.namelist()
        if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", name)
    )
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise ExportError("The downloaded XLSX does not contain a worksheet XML file.")
    raise ExportError(
        f"Could not identify the worksheet for '{wanted_title}' inside the XLSX."
    )


def set_cell_to_value(cell: etree._Element, value: Any) -> None:
    # Keep attributes such as r="A1" and s="12" (style). Only replace formula/value payload.
    for child in list(cell):
        local = etree.QName(child).localname
        if local in {"f", "v", "is"}:
            cell.remove(child)

    cell.attrib.pop("t", None)

    if value is None or value == "":
        return

    if isinstance(value, bool):
        cell.set("t", "b")
        v = etree.SubElement(cell, f"{{{MAIN_NS}}}v")
        v.text = "1" if value else "0"
        return

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        v = etree.SubElement(cell, f"{{{MAIN_NS}}}v")
        v.text = repr(value)
        return

    text = str(value)
    if text in EXCEL_ERRORS:
        cell.set("t", "e")
        v = etree.SubElement(cell, f"{{{MAIN_NS}}}v")
        v.text = text
        return

    cell.set("t", "inlineStr")
    inline = etree.SubElement(cell, f"{{{MAIN_NS}}}is")
    t = etree.SubElement(inline, f"{{{MAIN_NS}}}t")
    if text.startswith(" ") or text.endswith(" ") or "\n" in text:
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = text


def patch_worksheet_xml(xml_bytes: bytes, effective_values: list[list[Any]]) -> tuple[bytes, int, int]:
    parser = etree.XMLParser(remove_blank_text=False, recover=False, huge_tree=True)
    root = etree.fromstring(xml_bytes, parser=parser)

    formula_cells = 0
    values_replaced = 0

    # Replace only formula cells. Static text, rich text, and manually entered values
    # stay byte-for-byte conceptually unchanged except for XML serialization.
    for cell in root.xpath(".//*[local-name()='c']"):
        formula_nodes = cell.xpath("./*[local-name()='f']")
        if not formula_nodes:
            continue

        formula_cells += 1
        ref = cell.get("r", "")
        match = CELL_REF_RE.match(ref)
        if not match:
            continue

        col = column_number(match.group(1))
        row = int(match.group(2))
        value = matrix_value(effective_values, row, col)
        set_cell_to_value(cell, value)
        values_replaced += 1

    # Remove standard and extension-based dropdown/data-validation collections.
    validation_nodes = root.xpath(".//*[local-name()='dataValidations']")
    validations_removed = len(validation_nodes)
    for node in validation_nodes:
        parent = node.getparent()
        if parent is not None:
            parent.remove(node)

    # Clean empty extension wrappers left behind after removing x14 validations.
    for ext in list(root.xpath(".//*[local-name()='ext']")):
        if len(ext) == 0 and not (ext.text or "").strip():
            parent = ext.getparent()
            if parent is not None:
                parent.remove(ext)

    for extlst in list(root.xpath(".//*[local-name()='extLst']")):
        if len(extlst) == 0 and not (extlst.text or "").strip():
            parent = extlst.getparent()
            if parent is not None:
                parent.remove(extlst)

    output = etree.tostring(
        root,
        xml_declaration=True,
        encoding="UTF-8",
        standalone=True,
    )
    return output, values_replaced, validations_removed


def clean_xlsx(
    raw_xlsx: bytes,
    sheet_title: str,
    effective_values: list[list[Any]],
) -> tuple[bytes, int, int]:
    input_buffer = BytesIO(raw_xlsx)
    output_buffer = BytesIO()

    with zipfile.ZipFile(input_buffer, "r") as zin:
        target_xml = worksheet_xml_path(zin, sheet_title)
        patched_xml, formulas_replaced, validations_removed = patch_worksheet_xml(
            zin.read(target_xml), effective_values
        )

        with zipfile.ZipFile(output_buffer, "w") as zout:
            for item in zin.infolist():
                payload = patched_xml if item.filename == target_xml else zin.read(item.filename)
                zout.writestr(item, payload)

    return output_buffer.getvalue(), formulas_replaced, validations_removed


def export_visible_sheets(
    spreadsheet_input: str,
    client_secret_path: str,
    output_root: str,
    log,
    progress,
) -> Path:
    spreadsheet_id = extract_spreadsheet_id(spreadsheet_input)
    creds = get_credentials(client_secret_path)

    sheets_service = build("sheets", "v4", credentials=creds, cache_discovery=False)
    session = AuthorizedSession(creds)

    spreadsheet_title, visible_sheets = get_spreadsheet_metadata(
        sheets_service, spreadsheet_id
    )

    if not visible_sheets:
        raise ExportError("No visible grid sheets were found.")

    stamp = time.strftime("%Y-%m-%d_%H%M%S")
    output_dir = Path(output_root) / f"{safe_filename(spreadsheet_title)} - XLSX - {stamp}"
    output_dir.mkdir(parents=True, exist_ok=True)

    log(f"Spreadsheet: {spreadsheet_title}")
    log(f"Visible sheets: {len(visible_sheets)}")
    log(f"Output: {output_dir}")

    failures: list[str] = []

    for index, sheet in enumerate(visible_sheets, start=1):
        title = sheet["title"]
        gid = sheet["sheetId"]
        progress(index - 1, len(visible_sheets), f"Reading {title}")
        log(f"[{index}/{len(visible_sheets)}] {title}: reading calculated values...")

        try:
            effective_values = get_effective_values(
                sheets_service, spreadsheet_id, title
            )

            progress(index - 1, len(visible_sheets), f"Downloading {title}")
            raw_xlsx = download_sheet_xlsx(
                session, spreadsheet_id, gid, title
            )

            progress(index - 1, len(visible_sheets), f"Cleaning {title}")
            cleaned_xlsx, formulas_replaced, validations_removed = clean_xlsx(
                raw_xlsx, title, effective_values
            )

            output_file = output_dir / f"{safe_filename(title)}.xlsx"
            output_file.write_bytes(cleaned_xlsx)

            log(
                f"    Saved {output_file.name} | "
                f"formula cells frozen: {formulas_replaced:,} | "
                f"validation blocks removed: {validations_removed}"
            )

        except Exception as exc:
            failures.append(f"{title}: {exc}")
            log(f"    FAILED: {exc}")

        progress(index, len(visible_sheets), f"Finished {title}")

    if failures:
        failure_file = output_dir / "EXPORT_ERRORS.txt"
        failure_file.write_text("\n".join(failures), encoding="utf-8")
        log(f"Completed with {len(failures)} failure(s). See EXPORT_ERRORS.txt")
    else:
        log("All visible sheets exported successfully.")

    return output_dir


class ExporterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("760x590")
        self.minsize(700, 530)

        self.events: queue.Queue = queue.Queue()
        self.worker: threading.Thread | None = None
        self.last_output: Path | None = None

        settings = load_settings()
        self.sheet_var = tk.StringVar(value=settings.get("spreadsheet", ""))
        self.credentials_var = tk.StringVar(value=settings.get("credentials", ""))
        default_downloads = str(Path.home() / "Downloads")
        self.output_var = tk.StringVar(value=settings.get("output", default_downloads))
        self.status_var = tk.StringVar(value="Ready")

        self._build_ui()
        self.after(100, self._poll_events)

    def _build_ui(self):
        container = ttk.Frame(self, padding=18)
        container.pack(fill="both", expand=True)
        container.columnconfigure(1, weight=1)
        container.rowconfigure(8, weight=1)

        ttk.Label(container, text="Google Sheets → Separate Excel Files", font=("Segoe UI", 15, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 4)
        )
        ttk.Label(
            container,
            text="Visible tabs only • formulas frozen to current values • dropdowns removed • formatting retained",
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 16))

        ttk.Label(container, text="Spreadsheet URL / ID").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(container, textvariable=self.sheet_var).grid(row=2, column=1, columnspan=2, sticky="ew", pady=5)

        ttk.Label(container, text="OAuth credentials.json").grid(row=3, column=0, sticky="w", pady=5)
        ttk.Entry(container, textvariable=self.credentials_var).grid(row=3, column=1, sticky="ew", pady=5)
        ttk.Button(container, text="Browse", command=self._browse_credentials).grid(row=3, column=2, padx=(8, 0), pady=5)

        ttk.Label(container, text="Save to").grid(row=4, column=0, sticky="w", pady=5)
        ttk.Entry(container, textvariable=self.output_var).grid(row=4, column=1, sticky="ew", pady=5)
        ttk.Button(container, text="Browse", command=self._browse_output).grid(row=4, column=2, padx=(8, 0), pady=5)

        button_row = ttk.Frame(container)
        button_row.grid(row=5, column=0, columnspan=3, sticky="ew", pady=(14, 8))
        button_row.columnconfigure(0, weight=1)
        self.export_button = ttk.Button(button_row, text="Export Visible Sheets", command=self._start_export)
        self.export_button.grid(row=0, column=0, sticky="ew")
        ttk.Button(button_row, text="Open Output", command=self._open_output).grid(row=0, column=1, padx=(8, 0))
        ttk.Button(button_row, text="Reset Google Login", command=self._reset_login).grid(row=0, column=2, padx=(8, 0))

        self.progress = ttk.Progressbar(container, mode="determinate", maximum=100)
        self.progress.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(4, 4))
        ttk.Label(container, textvariable=self.status_var).grid(row=7, column=0, columnspan=3, sticky="w", pady=(0, 8))

        self.log_text = tk.Text(container, height=18, wrap="word", font=("Consolas", 9))
        self.log_text.grid(row=8, column=0, columnspan=3, sticky="nsew")
        scroll = ttk.Scrollbar(container, orient="vertical", command=self.log_text.yview)
        scroll.grid(row=8, column=3, sticky="ns")
        self.log_text.configure(yscrollcommand=scroll.set)

    def _browse_credentials(self):
        path = filedialog.askopenfilename(
            title="Select Google OAuth Desktop credentials JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            self.credentials_var.set(path)

    def _browse_output(self):
        path = filedialog.askdirectory(title="Select output folder")
        if path:
            self.output_var.set(path)

    def _start_export(self):
        if self.worker and self.worker.is_alive():
            return

        spreadsheet = self.sheet_var.get().strip()
        credentials = self.credentials_var.get().strip()
        output = self.output_var.get().strip()

        if not spreadsheet:
            messagebox.showerror(APP_NAME, "Enter the Google Sheets URL or spreadsheet ID.")
            return
        if not credentials:
            messagebox.showerror(APP_NAME, "Select your OAuth credentials.json file.")
            return
        if not output:
            messagebox.showerror(APP_NAME, "Select an output folder.")
            return

        save_settings(
            {
                "spreadsheet": spreadsheet,
                "credentials": credentials,
                "output": output,
            }
        )

        self.log_text.delete("1.0", "end")
        self.progress["value"] = 0
        self.status_var.set("Starting...")
        self.export_button.configure(state="disabled")

        self.worker = threading.Thread(
            target=self._worker_export,
            args=(spreadsheet, credentials, output),
            daemon=True,
        )
        self.worker.start()

    def _worker_export(self, spreadsheet: str, credentials: str, output: str):
        def log(message: str):
            self.events.put(("log", message))

        def progress(done: int, total: int, status: str):
            percent = 0 if not total else int(done * 100 / total)
            self.events.put(("progress", percent, status))

        try:
            output_dir = export_visible_sheets(
                spreadsheet, credentials, output, log, progress
            )
            self.events.put(("done", str(output_dir)))
        except Exception as exc:
            self.events.put(("fatal", str(exc)))

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]

                if kind == "log":
                    self.log_text.insert("end", event[1] + "\n")
                    self.log_text.see("end")
                elif kind == "progress":
                    self.progress["value"] = event[1]
                    self.status_var.set(event[2])
                elif kind == "done":
                    self.last_output = Path(event[1])
                    self.progress["value"] = 100
                    self.status_var.set("Complete")
                    self.export_button.configure(state="normal")
                    messagebox.showinfo(APP_NAME, f"Export finished.\n\n{self.last_output}")
                elif kind == "fatal":
                    self.status_var.set("Failed")
                    self.export_button.configure(state="normal")
                    messagebox.showerror(APP_NAME, event[1])
        except queue.Empty:
            pass

        self.after(100, self._poll_events)

    def _open_output(self):
        path = self.last_output or Path(self.output_var.get().strip() or Path.home() / "Downloads")
        if path.exists():
            os.startfile(path)  # Windows only, by design.
        else:
            messagebox.showerror(APP_NAME, "Output folder does not exist yet.")

    def _reset_login(self):
        if TOKEN_PATH.exists():
            try:
                TOKEN_PATH.unlink()
                messagebox.showinfo(APP_NAME, "Saved Google login removed. You will sign in again next export.")
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))
        else:
            messagebox.showinfo(APP_NAME, "There is no saved Google login to remove.")


def main():
    app = ExporterApp()
    app.mainloop()


if __name__ == "__main__":
    main()
