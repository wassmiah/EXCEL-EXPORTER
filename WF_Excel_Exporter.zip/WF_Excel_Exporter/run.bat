@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo Please run setup.bat first.
    pause
    exit /b 1
)
start "" .venv\Scripts\pythonw.exe wf_excel_exporter.py
