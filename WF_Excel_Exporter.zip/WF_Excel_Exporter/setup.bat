@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set PY=py
) else (
    set PY=python
)

%PY% -m venv .venv
if errorlevel 1 goto :error

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto :error

echo.
echo Setup complete.
echo Double-click run.bat to start WF Excel Exporter.
pause
exit /b 0

:error
echo.
echo Setup failed. Make sure Python 3.11+ is installed and try again.
pause
exit /b 1
